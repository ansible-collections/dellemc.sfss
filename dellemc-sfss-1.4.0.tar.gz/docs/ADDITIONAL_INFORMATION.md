Additional Information
## Release cadence
<release cadence>

## Versioing
* This product releases follow [semantic versioning](https://semver.org/).

## Deprecation
* <Product> deprecation cycle is aligned with [Ansible](https://docs.ansible.com/ansible/latest/dev_guide/module_lifecycle.html).

